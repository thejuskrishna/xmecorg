<?php
$secure_page=1;
include 'header.php';
?>
<?php

$page="gallery";

require("photogallery.php");



gallery(); 

?>

<?php
include 'footer.php';
?>