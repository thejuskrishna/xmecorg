<?php
  $PGTYPE="postgresql65";
  include "./db/postgresql.php";
?>