<?php check_security(); ?>
<?php
  writefile("all");
  QueMessage("All files rebuilt.");
?>
