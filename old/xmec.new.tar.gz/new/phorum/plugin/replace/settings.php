<?php
$pluginreplace = array();
?>