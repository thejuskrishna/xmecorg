<?php
$secure_page=1;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>Members >></B>Accounts</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

	<TABLE width=433>
	<TR><TD width=280 bgcolor=#DDDDDD><P class=body>Particulars </P></TD><TD bgcolor=#DDDDDD><P class=body>Income </P></TD><TD bgcolor=#DDDDDD><P class=body>Expenditure </P></TD><TD bgcolor=#DDDDDD><P class=body>Balance </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body>Earlier balance as on April 2001(Opening SB balance + FD transferred to SB) </P></TD><TD bgcolor=#66FFCC><P>&nbsp; </P></TD><TD bgcolor=#33CCFF><P>&nbsp; </P></TD><TD bgcolor=#99CCCC><P class=body>42,055.00 </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body>Membership fee from 1997-2001 Batch + money handed over by principal </P></TD><TD bgcolor=#66FFCC><P class=body>33,600.00 </P></TD><TD bgcolor=#33CCFF><P>&nbsp; </P></TD><TD bgcolor=#99CCCC><P class=body>75,655.00 </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body>Donation from Sooraj Lohithakshan & Feroz Kareem </P></TD><TD bgcolor=#66FFCC><P class=body>10,000.00 </P></TD><TD bgcolor=#33CCFF><P>&nbsp; </P></TD><TD bgcolor=#99CCCC><P class=body>85,655.00 </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body>Contribution from Placement cell </P></TD><TD bgcolor=#66FFCC><P class=body>7,281.00 </P></TD><TD bgcolor=#33CCFF><P>&nbsp; </P></TD><TD bgcolor=#99CCCC><P class=body>92,936.00 </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body>Water cooler repairs - 2 nos. </P></TD><TD bgcolor=#66FFCC><P>&nbsp; </P></TD><TD bgcolor=#33CCFF><P class=body>5,525.00 </P></TD><TD bgcolor=#99CCCC><P class=body>87,411.00 </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body>Purchase of books to Library </P></TD><TD bgcolor=#66FFCC><P>&nbsp; </P></TD><TD bgcolor=#33CCFF><P class=body>4,221.00 </P></TD><TD bgcolor=#99CCCC><P class=body>83,190.00 </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body>Remuneration paid to staff ( Clerk & peons) </P></TD><TD bgcolor=#66FFCC><P>&nbsp; </P></TD><TD bgcolor=#33CCFF><P class=body>1,100.00 </P></TD><TD bgcolor=#99CCCC><P class=body>82,090.00 </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body>Bathroom restoration</P></TD><TD bgcolor=#66FFCC><P>&nbsp; </P></TD><TD bgcolor=#33CCFF><P class=body>3,920.00 </P></TD><TD bgcolor=#99CCCC><P class=body>78,170.00 </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body>Purchase of water purifier (1 No.)- for cooler </P></TD><TD bgcolor=#66FFCC><P>&nbsp; </P></TD><TD bgcolor=#33CCFF><P class=body>5,100.00 </P></TD><TD bgcolor=#99CCCC><P class=body>73,070.00 </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body>Site hosting </P></TD><TD bgcolor=#66FFCC><P>&nbsp; </P></TD><TD bgcolor=#33CCFF><P class=body>15,293.00 </P></TD><TD bgcolor=#99CCCC><P class=body>57,777.00 </P></TD></TR>
	<TR><TD width=280 bgcolor=#FFFFCC><P class=body><b>Balance</b></P></TD><TD bgcolor=#66FFCC><P>&nbsp; </P></TD><TD bgcolor=#33CCFF><P>&nbsp; </P></TD><TD bgcolor=#99CCCC><P class=body><b>57,777.00</b> </P></TD></TR>
	</TABLE></P>
	
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE>
<BR><BR>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>
 	<TABLE width=433>
	<TR><TD width=443 bgcolor=#DDDDDD><P class=body>For queries on donations and XMEC accounts, contact <A href="mailto:viji@mec.ac.in" class=link>XMEC Treasurer</A></P></TD></TR>
	</TABLE></P>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE>
<BR><BR>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>
	<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<strong>XMEC Bank Account</strong></A>
	<HR color="#dddddd" height=1 width=100%>
 	<TABLE width=433>
	<TR><TD width=443 bgcolor=#DDDDDD><P class=body><strong>Alumni Association of Model Engineering College(AAMEC) <BR>State <strong>Bank of Travancore <BR>Edappally Branch <BR><BR>
	<B>Account No. 13317/106</B></P></TD></TR>
	</TABLE></P>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>

</TABLE><BR>
<!--center ends-->
<?php
$secure_page=0;
include 'footer.php';
?>
