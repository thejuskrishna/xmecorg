<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >> Letters >></B> Post Graduation in the USA</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<P class=body><strong>MS - Making a Decision</strong></big></P>
			<P class=body>Based on the factors discussed in the introduction, it is ultimately one�s call to decide whether one should apply for MS, for that matter immediately after the B Tech studies or after working for some time.</P>
			<P class=body>Both enjoy advantages and disadvantages. If one comes straight out of college, one doesn�t lose touch with studies and can finish studies earlier on in life. If one is planning to finish the GRE exams before graduating, it is always recommended to start preparing by the beginning of the fifth semester. So everything will be ready by the end of the sixth semester.</P>
			<P class=body>On the other hand if one decides to work for some years (we recommend not more than 2-3), then work experience in the field of studies helps a lot, and even otherwise there are many practical things that one can gain from work experience in any field. Moreover, one gets to be financially stable after working for some years and may be able to take a better decision on whether to study or work.</P><BR>
  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
$secure_page=0;
include 'footer.php';
?>

