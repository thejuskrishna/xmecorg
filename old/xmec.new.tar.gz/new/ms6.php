<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >> Letters >></B> Post Graduation in the USA</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD valign=top><P class=body><strong>MS - Assistantship</strong></P><BR>
<P class=body>This will be <i><strong>the topic of interest</i></strong> for almost all those who are interested in applying for MS. Always keep in mind that there is an earlier application deadline for financial aid in almost all the schools. So make sure to send the financial aid application and the general application pretty much in advance before this deadline. Some schools might be lenient in the time deadlines, but most of them are not. Also there will be a big crowd waiting for the financial assistance. So one has to be on time for this.</P>
<P class=body>Also start emailing the professors in one's area of specialization even before applying to the schools. So if some professor agrees to give an assistantship or is interested, one can apply to that school after that. But normally these professors' get too many emails that most of them get deleted immediately. However, one should not be disappointed by all this and should contact Professors as mush as possible. Also if one has some industry experience in the area of specialization one is planning, give special emphasis to that while trying to get in touch with the professors. Please go through the college web site and talk to alumni, students and department administrators to get an idea about the professors who have enormous amounts of money with them.</P>
<P class=body>Types of assistantships available:</P>
<img src="images/dot.gif">&nbsp;&nbsp;<a class=link href="ms6.php#a1">Research Assistantship</A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<a class=link href="ms6.php#a2">Teaching Assistantship</A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<a class=link href="ms6.php#a3">Graduate Assistantship</A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<a class=link href="ms6.php#a4">Hourly Jobs</A><BR><BR>

<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>
<img src="images/dot1.gif">&nbsp;&nbsp;<a class=link name="a1"><strong>Research Assistantship</strong></A>
<HR width=433 color=#DDDDDD>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#DDDDDD" width=400>
	<P class=body>This covers one's tuition expenses as well as gives one a good amount as stipend. In this case, one will be working as an assistant to one of the professors or will be doing some research job in one of the department laboratories. <i><strong>Generally one of the most precious option!</i></strong></P>
</TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="ms6.php"><img src="images/top.gif" border=0 align=right></A>

<BR><BR>

<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

<img src="images/dot1.gif">&nbsp;&nbsp;<a class=link name="a2"><strong>Teaching Assistantship</strong></A>
<HR width=433 color=#DDDDDD>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#DDDDDD" width=400>
	<P class=body>Most of the Teaching Assistantship (TA) covers one's tuition expenses as well as gives one some stipend amount too. However in some schools, they give only a stipend. The main job of the TA  is to teach some course for the under graduates or help the professor in grading/ conducting the exams and lab experiments. The teaching job can be in other departments also like Physics, Chemistry, Maths etc</P>
</TD>
</TR>
</TABLE>

	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>

<A href="ms6.php"><img src="images/top.gif" border=0 align=right></A><BR><BR>
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

<img src="images/dot1.gif">&nbsp;&nbsp;<a class=link name="a3"><strong>Graduate Assistantship</strong></A>
<HR width=433 color=#DDDDDD>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#DDDDDD" width=400>
	<P class=body>Graduate Assistantship (GA) in some schools covers one's tuition apart from the stipend, but in some schools they give the stipend amount. The main function of the GA will be to help some of the administrative sections of the school like the library, admissions department, general computer labs, Graduate department, Health department.</P>
</TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="ms6.php"><img src="images/top.gif" border=0 align=right></A><BR><BR>
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

<img src="images/dot1.gif">&nbsp;&nbsp;<a class=link name="a4"><strong>Hourly Jobs</strong></A>
<HR width=433 color=#DDDDDD>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#DDDDDD" width=400>
	<P class=body>There will be lot of job opportunities in the campus that will pays on an hourly basis. Some examples are maintaining the computer labs, data and telecom networks, front office assistants, dormitory assistants, web site designing, working in canteen as waiters (hey this is US of A!!) and all. <strong>In some schools, one can get some of these jobs even before reaching the campus through the job opportunities website</strong>. Also talk to the present students in the schools and get an idea about the places where they give jobs to the international students.</P>
</TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<P class=body><strong><i>To get an assistantship/job before reaching the campus is a tough thing that can happen.  Most of the students get the assistantship/job after reaching the campus. So the most important thing is to look for jobs as soon as one reaches the campus. The criteria for getting the jobs is mostly on a first come, first serve basis.</i></strong></P><BR><BR>



</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>
