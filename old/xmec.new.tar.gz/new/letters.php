<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >></B> Letters</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433>

		<P class=body><IMG src="images/pen.gif">&nbsp;&nbsp;<strong>Letters from XMECians</strong></A>
		<HR color="#dddddd" height="1" width="100%">
	<TABLE width=433>
		<TR><TD bgcolor=#E7F3FB>&nbsp;&nbsp;&nbsp;<A href="rem.php" class=link>XMECians fondly remember Dr. Sukulal</A></TD></TR>
				<TR><TD bgcolor=#eeeeee>&nbsp;&nbsp;&nbsp<A href="resume.php" class=link>Tips on Resume Drafting</A></TD></TR>
		<TR><TD bgcolor=#E7F3FB>&nbsp;&nbsp;&nbsp;<A href="bme.php" class=link>Careers Prospects after Biomedical Engineering</A></TD></TR>
		<TR><TD bgcolor=#eeeeee>&nbsp;&nbsp;&nbsp<A href="ms_letter.php" class=link>XMECians write on post-graduate studies in the USA</A></TD></TR>
		</TABLE>
            <P></P>
	
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE>

<BR><BR>

<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433>

		<P class=body><IMG src="images/pen.gif">&nbsp;&nbsp;<strong>Techno Trivia</strong></A>
		<HR color="#dddddd" height="1" width="100%">
	<TABLE width=433>
		<TR><TD bgcolor=#dddddd>&nbsp;&nbsp;&nbsp;<A href="chemistry.php" class=link>The Chemistry of Communication</A></TD>
		</TR></TABLE>
            <P></P>
	
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE>
  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>
