<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >> Letters >></B> Post Graduation in the USA</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<P class=body><strong>MS - Application Process</strong><P class=body>Have the GRE &amp; TOEFL scores ready by the time.When one goes for the exam, please make sure that one has the score reported to the three main schools one is seriously planning to apply</P><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<a class=link href="ms3.html#p1">Statement of Purpose</A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<a class=link href="ms3.html#p2">Resume </A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<a class=link href="ms3.html#p3">Recommendation Letters </A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<a class=link href="ms3.html#p4">Official Transcripts </A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<a class=link href="ms3.html#p5">Application Forms </A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<a class=link href="ms3.html#p6">Deadlines </A><BR><BR>

<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>
<img src="images/dot1.gif">&nbsp;&nbsp;<a class=link name="p1"><strong>Statement of Purpose</strong></A>
<HR width=433 color=#DDDDDD>
<P class=body>Statement of Purpose (SOP) is a document which explains one�s career goals and fields of interests as well as background with the full project, seminar and school details. This is some thing which every school needs as part of the application process and carries a fair weightage in some schools.</P>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#DDDDDD" width=143><P class=body><strong>Sample of Statement of Purpose </strong></P></TD>
<TD bgcolor="#DDDDDD" width=290>
	<P class=body>
	<UL><LI class=body><a class=link href="http://www.statementofpurpose.com">www.statementofpurpose.com</a></LI>
	<LI class=body>Use Google to search for sample SOPs</LI>
	</UL></P>
</TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<a class=link href="ms3.html"><img src="images/top.gif" border=0 align=right></A>

<BR><BR>

<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

<img src="images/dot1.gif">&nbsp;&nbsp;<a class=link name="p2"><strong>Resume </strong></A>
<HR width=433 color=#DDDDDD>
<P class=body>A resume in US format is another important application criteria. The resume in US format is some thing that is different from what one has in India. This is some thing important from the assistantship application perspective too.</P>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#DDDDDD" width=143><P class=body><strong>Sample Resume </strong></P></TD>
<TD bgcolor="#DDDDDD" width=290>
	<P class=body>
	<UL><LI class=body><a class=link href="http://home.okstate.edu/homepages.nsf/toc/sampleresume">From Oklahoma University Site</a></LI>
	</UL></P>
</TD>
</TR>
</TABLE>

	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>

<A href="ms3.html"><img src="images/top.gif" border=0 align=right></A><BR><BR>
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433 >

<img src="images/dot1.gif">&nbsp;&nbsp;<a class=link name="p3"><strong>Recommendation Letters </strong></A>
<HR width=433 color=#DDDDDD>
<P class=body>The best authorities to issue a recommendation letter will be the Principal of one�s College, External project guide and the Head of Dept (respective departments). The schools in most of the cases will provide the format of the recommendation letters. Please have a relaxed chat with the person who intends to issue the recommendation letters and make sure that he is going to include only excellent recommendations in the letter. In some applications, one has to prepare a standard format for the recommendation letters, though rarely. Try to follow the pattern of the recommendation letters provided by other schools. If one has work experience, get one from one�s manager, if one is confident that he or she will give an excellent recommendation.</P>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD></TD>
<TD></TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="ms3.html"><img src="images/top.gif" border=0 align=right></A><BR><BR>
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

<img src="images/dot1.gif">&nbsp;&nbsp;<a class=link name="p4"><strong>Official Transcripts</strong></A>
<HR width=433 color=#DDDDDD>
<P class=body>One has to apply for the official transcripts from the university and make sure that the university sends it on time. This is a slightly expensive process especially in CUSAT.</P>
<P class=body>Please confirm that the university has sent the transcripts by doing proper follow up work. In most cases, since US universities refer one�s name as Last Name, First Name. CUSAT transcripts many a times have only initials of one�s surname; there is a potential danger of the university not finding a match in names.<strong> Hence a follow up is very crucial and be wary of this problem.</strong></P>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD></TD>
<TD></TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="ms3.html"><img src="images/top.gif" border=0 align=right></A><BR><BR>
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

<img src="images/dot1.gif">&nbsp;&nbsp;<a class=link name="p5"><strong>Application Forms</strong></A>
<HR width=433 color=#DDDDDD>
<P class=body>Fill up the application form in full and send it with the required amount of money. One can also apply online using the application form on web and send the money with the rest of the application materials.</P>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD></TD>
<TD></TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="ms3.html"><img src="images/top.gif" border=0 align=right></A><BR><BR>
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

<img src="images/dot1.gif">&nbsp;&nbsp;<a class=link name="p6"><strong>Deadlines</strong></A>
<HR width=433 color=#DDDDDD>
<P class=body>To be always on the safer side, it is better to start the application process at least a year before the deadlines. Most of the admissions take place for the Fall semester. Of course, a few schools have admissions in Spring semester too. But the chances of getting an assistantship and other financial assistances are much higher in Fall semester compared to the Spring semester.</P>
<P class=body><strong>The Fall semester starts in the first week of September</strong> and the <strong>Spring semester starts in the first week of January</strong>. The application deadlines for Fall semesters fall around December-March and October for Spring semesters (previous year) respectively. In most schools, there is a separate earlier deadline for financial aid consideration.</P>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD></TD>
<TD></TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="ms3.html"><img src="images/top.gif" border=0 align=right></A><BR><BR>
  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>

