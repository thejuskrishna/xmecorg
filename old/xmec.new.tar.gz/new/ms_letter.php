<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >><A class=link HREF="letters.php"> Letters</A> >></B> Post Graduation in the USA</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<P class=body>Everyone has a field of interest. Some of us plan to go further into some of fields of interest (technical) and some decide to go further with intentions and dreams about management and corporate ladders.For the people in the first category, it is time to decide what is their field and to start preparing for the same. As Lao �Tzu said,<I> A journey of thousand miles begins with a single step</I>, it is already late to take the first step.</P>
<P class=body>In the early nineties and before, there was a general feeling that if one gets specialized in any of the technical fields, one would have to pursue work only outside India since the opportunities we had in our country for such specialized work were rare. But things have changed for the better. Now major Multinational companies in the fields of Information Technology, Medical Instrumentation and Telecom have huge development centers there in India. In the centers of companies like Lucent, TI, Motorola, Cisco, GE, Avaya et al, a great deal of cutting egde technology is being developed. It is in the interest of these companies to develop more in these centers since the operating costs are very less. So people who do their higher studies can enjoy the added option of returning to their home country to build a budding career. Believe it or not, the compensation offered is worth the US degree one earns. So people who want to work in India also can pursue their studies and return. </span></P>
<P class=body>The exposure one gets in the American campus and the style of education are tremendous. One gets to know people from all backgrounds, lot of countries and cultures. US campuses are real cosmopolitan in nature. The exposure in the campus helps one a lot personally too. The facilities the campuses are state of the art and probably beyond expression. There is lot of research happening in the schools in US. So the labs are modern and sophisticated to say the least. </P>
<P class=body>In short, higher education in US universities is a treat, for those who love to study. However like every other thing good in life, it comes with a price, not a bad one though. It�s the attitude to work hard and smart; motivated and determined; right from the time one decides to apply; till one gets his or her degree. The aim in this article is to give a good and real feel of what to and what not to expect, so that one can make an informed decision on whether to pursue higher studies or not.</P>
<P class=body>As years pass by, the competition inside the campus is getting tough and henceforth the chance of getting an assistantship (i.e. financial assistance) is real daunting. As a candid advice, it is extremely difficult to get an assistantship before starting from India. Things may work out in the first semester in once one reaches the campus and meet the professors, but to be honest, we believe that good chances for an assistantship surface only from the second semester. The moment one reaches the campus it is a question of survival. The most crucial factor is the preparedness for real hard and industrious work. The competition is always with students from IIT (these people make a difference!!) and the creamy layer from other schools. Also there is also going to be a big cultural shock when one reaches US. If one ends up in a campus where there are few Indian students, it is gonna be a big shock. Also the restricted life with the on-campus income is going to be tough if one had been accustomed to an extravagant �freaking� life style pursued during college days or salaried days!</P>
<P class=body>We have tried to organize the entire gamut of events into logical steps. The main steps can be categorized as:</P><BR><BR>

<TABLE border=0 cellPadding=0 cellSpacing=0 width="433">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

	<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<big><strong>MS Studies</strong></big>
	<HR color="#dddddd" height=1 width=100%>
	<TABLE width=433>
	<TR><TD width = 20><IMG src="images/dot.gif"></TD><TD><P><a class=link href="ms1.php" >Making a decision</a></P></TD></TR>
	<TR><TD width = 20><IMG src="images/dot.gif"></TD><TD bgcolor=#DDDDDD><P><a class=link href="ms2.php">Preparing For the Test</a></P></TD></TR>
	<TR><TD width = 20><IMG src="images/dot.gif"></TD><TD><P><a class=link href="ms3.php">Application Process</a></P></TD></TR>
	<TR><TD width = 20><IMG src="images/dot.gif"></TD><TD bgcolor=#DDDDDD><P><a class=link href="ms4.php"> Selection of schools</a></P></TD></TR>
	<TR><TD width = 20><IMG src="images/dot.gif"></TD><TD><P><a class=link href="ms5.php"> Monetary Aspects</a></P></TD></TR>
	<TR><TD width = 20><IMG src="images/dot.gif"></TD><TD bgcolor=#DDDDDD><P><a class=link href="ms6.php">Assistantship</a></P></TD></TR>
	<TR><TD width = 20><IMG src="images/dot.gif"></TD><TD><P><a class=link href="ms7.php">Areas of Research and Specialization</a></P></TD></TR>
	<TR><TD width = 20><IMG src="images/dot.gif"></TD><TD bgcolor=#DDDDDD><P><a class=link href="ms8.php">Admission Tips</a></P></TD></TR>
	</TABLE>
	
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR><BR>
<P class=body><strong><i>The information provided above is our personal view. Please try to collect similar information from as many different sources as you can. There are a lot of small details that we could not include due to space and time constraints and we are most interested in helping you in all ways we can. So please feel free to contact us at our personal email IDs or at </strong></i><A href="higherstudies.html" class=link>Higher Studies@XMEC</A></P><BR>
<P class=body><I>About the Authors</I></P>
<P class=body><I><A class=link href="mailto:jobybabu@yahoo.com">Joby Babu</A> (EE 94-98): M.S in Telecom, NJIT (New Jersey Institute of Technology, New Jersey). Currently working in Motorola, NJ </I></P>
<P class=body><I><A class=link href="mailto:praveen@winlab.rutgers.edu">Praveen Gopalakrishnan</A> (EE 94-98): Doing M.S in Communications from Rutgers University (Winlab), New Jersey</I></P>
<P class=body><I><A class=link href="mailto:renishp@ivega.com">Renish Pynadath</A> (EE 94-98): MBA from Indian Institute of Management, Bangalore (IIMB), Currently working in Honeywell, Bangalore</I></P>
<P class=body><I><A class=link href="mailto:sheebaarnold@hotmail.com">Sheeba Rani Arnold</A> (BE 94-98): M.S in Biomedical Engineering from NJIT, M.S in Computer Engineering from NJIT (New Jersey Institute of Technology, New Jersey).</I></P><BR>
  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>
