<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >> Letters >></B> Post Graduation in the USA</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD class=body><BR><strong>Areas of Specialization</strong>
		
		<P class=body><strong>Electrical Engineering:</strong><UL>
		<LI class=body>Communications / Wireless</LI>
		<LI class=body>Signal Processing (DSP)</LI>
		<LI class=body>Computer Networking (Mobile)</LI>
		<LI class=body>VLSI</LI>
		</UL></P><BR>
		<P class=body><strong>Computer Engineering:</strong><UL>
		<LI class=body>Computer Science (OS, DBMS etc)</LI>
		<LI class=body>Software Engineering</LI>
		<LI class=body>Computer Vision And 3 D modeling</LI>
		<LI class=body>Computer Networking</LI>
		</UL></P><BR>
		<P class=body><strong>Biomedical Engineering:</strong><UL>
		<LI class=body>Biomaterials and Tissue Engineering</LI>
		<LI class=body>Instrumentation and Medical Devices</LI>
		<LI class=body>Biotechnology</LI>
		<LI class=body>Medical Imaging/Visualization/Computational Analysis </LI>
		<LI class=body>Medical Physiology </LI>
		<LI class=body>Occupational Health/Environmental Design/Rehabilitation</LI>
		</UL></P>
		
		<P class=body>It is interesting to note that <strong>there is no Electronics Engineering, but only Electrical Engineering (EE) in USA</strong>. As we all know EE is a very wide area and in some universities they have Electrical and Computer engineering department apart from a Computer Science department. </P>
		<P class=body>In MEC, since more emphasis is given on communications, that might be one area which is good for most. Again this depends only on personal interests. Communications today mostly focus on wireless communications that is basically all about how to send data at very fast rates without wires. Typical applications are mobile phones, wireless laptops etc. Related areas are signal processing, and networking. One important thing to note is that maths, more specifically linear algebra, stochastic processes and so on are inevitable if one deal with communications area. So a strong advice would be to keep away from this if one are allergic or disinterested in math.</P>
		
		<P class=body>Some excellent universities for pursuing higher studies in communications are Stanford, Berkley, MIT, UCSD, UCSB, USC, GeorgiaTech, Virginia Tech, Rutgers (Winlab), and so on. We strongly advice everyone to visit some of these web sites and get to know about the research and other details.</P>
		
		<P class=body>The areas of VLSI (IC manufacturing etc), Computer Engineering (vision, 3D modeling etc) are equally interesting.</P>
		<BR></TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>
