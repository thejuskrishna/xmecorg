<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >> Letters >></B> Post Graduation in the USA</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD valign=top class=body><strong>MS - More Admission Tips</strong><BR><BR><BR>

<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433 class=body>
<IMG src="images/dot1.gif">&nbsp;&nbsp;<strong>GRE score</strong>
<HR width=433 color=#dddddd>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=400><P class=body>Take the exam seriously. Try to score around 2100+.</P></TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433  class=body>

<IMG src="images/dot1.gif">&nbsp;&nbsp;<strong>Academic Projects</strong>
<HR width=433 color=#dddddd>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=400><P class=body>Make sure that the Seminars, Mini Project and the Main Project pertain to one's <strong><i>Areas of Interest</i></strong> especially the area in which one intends to do his or her MS in.</P></TD>
</TR>
</TABLE>

	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>

<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433 class=body>

<IMG src="images/dot1.gif">&nbsp;&nbsp;<strong>Paper Presentation</strong>
<HR width=433 color=#dddddd>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=400><P class=body>One doesn't do paper presentations, seminars and don't publish papers along with the professors in our college. <i><strong>This is something we have to inculcate in our college in the near future</i></strong>. We should try to present some paper in whatever technical stages possible. Most of the engineering colleges host some paper presentation series every year. Please take it seriously and present a paper in one's area of interest. This will give one big credits while applying for MS. This applies to all post graduation studies.</P></TD>
</TR>
</TABLE>

	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433 class=body>
<IMG src="images/dot1.gif">&nbsp;&nbsp;<strong>Recommendation Letters</strong>
<HR width=433 color=#dddddd>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=400><P class=body>Please make sure to get nice recommendation letters from College Principal, Main Project Guide, Head of the Department et al.</P></TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>

<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433 class=body>
<IMG src="images/dot1.gif">&nbsp;&nbsp;<strong>Work Experience</strong>
<HR width=433 color=#dddddd>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=400><P class=body>If one is planning to go for higher studies after working for an year or two with intentions of making some money for your education, please take special effort to get a job that matches one's area of interest. This will always add bonus points while applying for admissions. But this is not possible always since one can't fully expect to get into that job that interests most.</P></TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433 class=body>
<IMG src="images/dot1.gif">&nbsp;&nbsp;<strong>Follow up</strong>
<HR width=433 color=#dddddd>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=400><P class=body>Once one is done with application process, follow up with the admissions office as well as one's department to get the status. Please take the help of the present students in the school to get the status of one's application.Make good relations with Present Students:  Keep in mind that the students who are studying in the school are the most helpful people. So try to create good relations with the students in the schools where one is planning to apply. Try to get in touch with as many students as possible since one can expect a good response from only 50% of the whole lot. This is not because these people are not interested in helping, but they might be busy with whole lot of other work. </P></TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
$secure_page=0;
include 'footer.php';
?>
