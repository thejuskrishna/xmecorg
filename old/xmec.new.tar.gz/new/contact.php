<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>XMEC >></B>Contacts</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

	<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<strong>College</strong></A>
	<HR color="#dddddd" height=1 width=100%>
	<TABLE width=433>
	<TR><TD width=280><P class=body>Principal </P></TD><TD><P><A href="mailto:jyothijohn@mec.ac.in"class=link> Prof. Jyothi John </A></P></TD></TR>
	<TR><TD width=280 bgcolor=#DDDDDD><P class=body>Head of Dept, Computer Engg </P></TD><TD bgcolor=#DDDDDD><P><A href="mailto:jyothijohn@mec.ac.in"class=link> Prof. Jyothi John </A></P></TD></TR>
	<TR><TD width=280><P class=body>Head of Dept, Electronics & Biomedical Engg </P></TD><TD><P class=body> Ms. Jessy John </P></TD></TR>
	<TR><TD width=280 bgcolor=#DDDDDD><P class=body>Head of Dept, Electronics Engg </P></TD><TD bgcolor=#DDDDDD><P><A href="mailto:jaya@mec.ac.in"class=link> Ms. Jayashree M </A></P></TD></TR>
	</TABLE></P>
	
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE>
<BR><BR>

<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>

		<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<strong>Placements</strong></A>
		<HR color="#dddddd" height=1 width=100%>
	<TABLE width=433>
		<TR><TD width=280 ><P class=body>&nbsp;&nbsp;&nbsp;Staff in Charge </P></TD><TD ><P><A href="mailto:jaya@mec.ac.in"class=link> Ms. Jayashree M </A></P></TD></TR>
		<TR><TD width=280 bgcolor=#DDDDDD><P class=body>&nbsp;&nbsp;&nbsp;Student Coordinators </P></TD><TD bgcolor=#DDDDDD><P><A href="mailto:pc@mec.ac.in" class=link> pc@mec.ac.in </A></P></TD>
		</TR></TABLE></P>
	
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE>


<BR>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433>


		<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<strong>Alumni</strong></A>
		<HR color="#dddddd" height=1 width=100%>
	<TABLE width=433>
		<TR><TD width=280 bgcolor=#DDDDDD><P class=body>Executive Committee President </P></TD><TD bgcolor=#DDDDDD><P><A href="search.php?&name=vidhiprasad+k+v&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Vidhi Prasad </A></P></TD></TR>
		<TR><TD><P class=body>Bangalore Chapter President </P></TD><TD><P><A href="search.php?&name=manu++sreenivasan&worktype=&year=&company=&branch=&location=&.s=Search" class=link> Manu Sreenivasan </A></P></TD></TR>
		<TR><TD bgcolor=#DDDDDD><P class=body>Chennai Chapter President </P></TD><TD bgcolor=#DDDDDD><P><A href="search.php?&name=prinu+shaan+nazeem&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Prinu Nazeem </A></P></TD></TR>
		<TR><TD><P class=body>US East Coast Chapter Coordinator </P></TD><TD><P><A href="search.php?&name=joby++babu&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Joby Babu </A></P></TD></TR>
		<TR><TD bgcolor=#DDDDDD><P class=body>US West Coast Chapter Coordinator </P></TD><TD bgcolor=#DDDDDD><P><A href="search.php?&name=faisal+p+a&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Faisal P A </A></P></TD></TR>
		<TR><TD><P class=body>XMEC YahooGroups Moderator </P></TD><TD><P><A href="search.php?&name=vyas+mohan+thottathil&worktype=&year=&company=&branch=&location=&.s=Search" class=link> Vyas Mohan Thottathil </A></P></TD></TR>
		<TR><TD bgcolor=#DDDDDD><P class=body>XMEC Webmasters </P></TD><TD bgcolor=#DDDDDD><P><A href="mailto:webmasters@xmec.net" class=link> Webmasters </A></P></TD></TR>
		</TABLE>
		</P>
	
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE></TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
$secure_page=1;
include 'footer.php';
?>

