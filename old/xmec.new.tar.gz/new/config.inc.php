<?
  $config_databasehost = 'mysql.addr.com';  /* This is the mysql server name */
  $config_databasename = 'xmec'; /* Name of the database used */
  $config_databaseuser = 'xmec'; /* Name used to connect to the server database.  Must have read/write access */
  $config_databasepassword = 'raskals'; /* Password used to connect to the server database */
?>
