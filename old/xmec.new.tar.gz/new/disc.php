<?php
$secure_page=1;
include 'header.php';
?>
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>Disclaimer >></B></TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<P class=body>xmec.net provides complete information on XMEC, the alumni association of Model Engineering College, Kochi and its theatre of action. The content on the website is presented in a summary form, is general in nature, and is provided for information purposes only. XMEC has exercised reasonable care in developing the information incorporated into this website. XMEC maintains this website to enhance access to information about the organisation, and to enhance access to all XMECians worldwide and the contents will be upgraded on a regular basis. While we try to keep the information as current and accurate as possible, we make no warranty of any kind, implied or expressed, as to its accuracy, completeness or appropriateness for any purpose. </P>
<P class=body>XMEC reserves the right to change or discontinue at any time, any aspect or feature of this site. xmec.net does not recommend or endorse any specific information that may be mentioned on the site and does not assume any liability for the contents of any material provided on the site. XMEC does not assume any liability or responsibility for damage or injury to any person or property arising directly or indirectly from the use of any information, idea or instruction contained in the materials provided to you via xmec.net. </P>
<b>USE OF CONTENT: COPYRIGHT </b>
<P class=body>The material contained in this website belongs to XMEC, the alumni association of Model Engineering College. Duplicating the information provided in the website in any other manner or use of this information by any third person or party, in full or in part, without the explicitly written permission of XMEC is strictly prohibited, and will be illegal and liable for legal action. </P>
<P class=body>Unauthorized use of the information (content) may violate copyright, trademark, and other laws. None of the content may be reverse-engineered, disassembled, decompiled, reproduced, transcribed, stored in a retrieval system, translated into any language or computer language, re-transmitted in any form or by any means (electronic, mechanical, photoreproduction, recordation or otherwise), resold or redistributed without the prior written consent of XMEC, except that you may reproduce limited excerpts of the data for personal use only, provided that each such a copy contains a copyright notice. </P>
<P class=body>You may not sell or modify the Content or reproduce, display, publicly perform, distribute or otherwise use the Content in any way for any public or commercial purpose. The use of the content on any other website or in a networked computer environment for any purpose is prohibited. XMEC reserves the right to change the contents of the site without prior notice. </P>
<P class=body>If any of these terms and conditions are violated, permission to use the content terminates automatically. The violator is expected to immediately destroy any copies he or she may possess in part or whole, of the content. </P>
<b>ASSOCIATION'S LIABILITY: DISCLAIMER OF CONSEQUENTIAL DAMAGES </b>
<P class=body>XMEC site and the content are provided on an �as is� basis without any warranties of any kind. The Content comes from sources believed to be accurate, but may contain inaccuracies or typographical errors. The use of the site and the content is at your own risk. XMEC assumes no liability for or relating to the delay, failure, interruption or corruption of any data or other information transmitted in connection with use of the site. </P>
<P class=body>XMEC and its members, to the fullest extent permitted by law, disclaim all warranties, expressed or implied, statutory or otherwise, including but not limited to the implied warranties of merchantability, non-infringement of their parties� rights, and fitness for particular purpose. XMEC make no representation or warranties about the accuracy, reliability, completeness, currentness or timeliness of the content, graphics, links or communications provided on or through the use of xmec.net. </P>
<P class=body>XMEC does not represent or guarantee the truthfulness, accuracy, or reliability of any information or of the material posted by Interactive Area users. XMEC does not endorse any opinions and feelings as expressed by such users of the interactive areas of the site. Your reliance of any sort of content posted in any interactive areas is at your own risk and you are solely responsible for any consequences arising out of such use. </P>
<b>LINKS TO OTHER SITES </b>
<P class=body>The XMEC site is facilitated with links to other sites or third party websites with sole intention of providing browser convenience. Links to other websites is not an endorsement by XMEC of the content on such third party sites. </P>
<P class=body>XMEC does not assume responsibility for the content, accuracy of information of linked third-party sites and does not make any representations regarding the content or accuracy of materials on such third party websites. </P>
<P class=body>If you decide to access linked third-party websites, you will be solely responsible for any consequences arising out of such use. You are required to acquaint yourself with the terms and conditions of the third party site. Your use of third-party websites is subject to the Terms and Conditions of use mentioned therein for such sites. </P>
<b>INDEMNITY </b>
<P class=body>You agree to defend, indemnify and hold XMEC, its officer bearers and members harmless from an against any claim, actions or demands, liabilities and settlements including without limitation, reasonable legal and accounting fees, resulting from, or alleged to result from, your use of the contents in a manner that violates or is alleged to violate these Terms and Conditions, XMEC shall provide notice to you promptly of any such claim, suite or proceeding and shall reasonably cooperate with you, at your expense, in your defense of any such claim suite or proceeding. </P>
<b>GENERAL </b>
<P class=body>You acknowledge that no joint venture, partnership, employment, or agency relationship exists between you and XMEC, as a result of your use of our site. You agree not to hold yourself out as a representative, agent or employee of XMEC, and that xmec.net will not be liable by reason of any representation, act or omission to act by you. </P>
<P class=body>xmec.net performance under this agreement is subject to all times to existing laws and legal process and nothing contained in this agreement is in derogation of XMEC right to comply with law enforcement request or requirements relating to a Member�s use of xmec.net or information provided to or gathered by XMEC with respect to such use. </P>
<P class=body>This Agreement constitutes the entire agreement between XMEC and you with respect to your use of xmec.net and it supersede all prior or contemporaneous communications and proposals, whether oral or written, between xmec.net and you with respect thereto. </P>
<P class=body>It is at the express wish of the parties that this agreement and all related documents have been drawn up in English. </P>
  	</TD>
  </TR>
</TABLE>

<?php
include 'footer.php';
?>